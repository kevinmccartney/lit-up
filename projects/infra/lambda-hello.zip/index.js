/**
 * Simple health check Lambda for API Gateway REST API (proxy integration).
 */
exports.handler = async (event) => {
  const body = {
    status: 'ok',
    requestId: event?.requestContext?.requestId,
    path: event?.path,
    httpMethod: event?.httpMethod,
  };

  return {
    statusCode: 200,
    headers: {
      'content-type': 'application/json; charset=utf-8',
      'cache-control': 'no-store',
    },
    body: JSON.stringify(body),
  };
};
